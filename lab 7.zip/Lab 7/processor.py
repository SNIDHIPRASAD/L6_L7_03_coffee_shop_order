"""Coffee shop order processor - hardened against invalid input.

Every function now validates its input and returns a safe value (``None``
or an empty dict) instead of raising, so malformed or hostile input can no
longer crash the caller.
"""
import math

MENU_PRICES = {
    "LAT": 4.50,
    "CAP": 4.00,
    "ESP": 3.00,
    "AME": 3.50,
    "MOC": 5.00,   # was "MOc" - could never match an upper-cased prefix
}


def lookup_drink_code(code_string):
    """Return the base price for a drink code prefix, or None if unknown.

    Fixes: None / non-string input (AttributeError) and unknown codes
    (KeyError); the menu key "MOc" could never match.
    """
    if not isinstance(code_string, str):
        return None
    return MENU_PRICES.get(code_string.strip().upper()[:3])


def calculate_average_shot_cost(pricing_csv):
    """Return the average of a CSV of non-negative prices, or None if invalid.

    Fixes: ZeroDivisionError on empty input, ValueError on non-numeric or
    empty elements, TypeError on None, and nan/inf values slipping through.
    """
    if not isinstance(pricing_csv, str):
        return None
    prices = []
    for part in pricing_csv.split(","):
        try:
            value = float(part.strip())
        except ValueError:
            return None
        if not math.isfinite(value) or value < 0:
            return None
        prices.append(value)
    average = sum(prices) / len(prices)
    return average if math.isfinite(average) else None


def parse_order_modifiers(order_spec):
    """Parse 'key:value;key:value' into a dict; malformed items are skipped.

    Fixes: ValueError when an item has no ':' or more than one ':', and
    AttributeError on None / non-string input.
    """
    modifier_dict = {}
    if not isinstance(order_spec, str):
        return modifier_dict
    for item in order_spec.split(";"):
        key, separator, value = item.partition(":")
        key = key.strip()
        if separator and key:
            modifier_dict[key] = value.strip()
    return modifier_dict


def main():
    """Interactive demo of the three (now safe) functions."""
    print("==== Running lookup_drink_code ====")
    drink_input = input("Enter drink code prefix (e.g. LAT, CAP, ESP): ")
    price = lookup_drink_code(drink_input)
    if price is None:
        print("Unknown drink code - no price available.")
    else:
        print("Base Price: $", price)

    print("\n==== Running calculate_average_shot_cost ====")
    shots_input = input("Enter CSV of shot prices (e.g. 1.0, 1.5, 2.0): ")
    avg_price = calculate_average_shot_cost(shots_input)
    if avg_price is None:
        print("Invalid shot prices - could not compute an average.")
    else:
        print("Average Shot Price: $", avg_price)

    print("\n==== Running parse_order_modifiers ====")
    spec_input = input("Enter modifiers (e.g. milk:oat;syrup:vanilla): ")
    mods = parse_order_modifiers(spec_input)
    print("Parsed Modifiers:", mods)


if __name__ == "__main__":
    main()
