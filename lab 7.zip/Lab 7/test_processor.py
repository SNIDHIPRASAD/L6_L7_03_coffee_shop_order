"""Lab 7 - property-based fuzz tests (Hypothesis) for processor.py."""
import math

from hypothesis import given, strategies as st
from processor import (lookup_drink_code, calculate_average_shot_cost,
                       parse_order_modifiers)

# Anything a careless caller (or an attacker) might pass in.
ANYTHING = st.one_of(
    st.text(), st.none(), st.integers(), st.floats(),
    st.booleans(), st.binary(), st.lists(st.integers()),
)


# --------------------------------------------------------------------------
# 1. "Must never crash" properties (text / None, as in the handout)
# --------------------------------------------------------------------------
@given(st.text() | st.none())
def test_lookup_drink_code_no_crash(s):
    try:
        lookup_drink_code(s)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"lookup_drink_code crashed with: {e!r} for {s!r}"


@given(st.text() | st.none())
def test_calculate_average_shot_cost_safe(s):
    try:
        calculate_average_shot_cost(s)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"calculate_average_shot_cost crashed with: {e!r} for {s!r}"


@given(st.text() | st.none())
def test_parse_order_modifiers_safe(s):
    try:
        parse_order_modifiers(s)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"parse_order_modifiers crashed with: {e!r} for {s!r}"


# --------------------------------------------------------------------------
# 2. Same properties for non-string types (ints, floats, bytes, lists ...)
# --------------------------------------------------------------------------
@given(ANYTHING)
def test_lookup_drink_code_any_type_no_crash(value):
    try:
        lookup_drink_code(value)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"lookup_drink_code crashed with: {e!r} for {value!r}"


@given(ANYTHING)
def test_average_any_type_no_crash(value):
    try:
        calculate_average_shot_cost(value)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"average crashed with: {e!r} for {value!r}"


@given(ANYTHING)
def test_parse_any_type_no_crash(value):
    try:
        parse_order_modifiers(value)
    except Exception as e:  # pylint: disable=broad-except
        assert False, f"parse crashed with: {e!r} for {value!r}"


# --------------------------------------------------------------------------
# 3. Correctness properties (valid inputs must give correct answers)
# --------------------------------------------------------------------------
@given(st.text() | st.none())
def test_lookup_returns_none_or_a_non_negative_price(s):
    price = lookup_drink_code(s)
    assert price is None or (isinstance(price, float) and price >= 0)


@given(st.sampled_from(["LAT", "CAP", "ESP", "AME", "MOC"]),
       st.text(max_size=5),
       st.booleans())
def test_known_prefix_is_found_in_any_case(prefix, suffix, lower):
    code = (prefix.lower() if lower else prefix) + suffix
    assert lookup_drink_code(code) is not None


@given(st.lists(st.floats(min_value=0, max_value=1000,
                          allow_nan=False, allow_infinity=False),
                min_size=1))
def test_average_of_valid_prices_is_within_min_and_max(prices):
    csv = ",".join(repr(p) for p in prices)
    avg = calculate_average_shot_cost(csv)
    assert avg is not None and math.isfinite(avg)
    assert min(prices) - 1e-6 <= avg <= max(prices) + 1e-6


@given(st.text() | st.none())
def test_average_result_is_none_or_finite_number(s):
    avg = calculate_average_shot_cost(s)
    assert avg is None or (isinstance(avg, float) and math.isfinite(avg))


@given(st.dictionaries(
    st.text(alphabet=st.characters(blacklist_characters=":;",
                                   blacklist_categories=("Cs", "Z", "Cc")),
            min_size=1),
    st.text(alphabet=st.characters(blacklist_characters=";",
                                   blacklist_categories=("Cs", "Z", "Cc"))),
))
def test_parse_round_trip(mods):
    spec = ";".join(f"{k}:{v}" for k, v in mods.items())
    assert parse_order_modifiers(spec) == mods


@given(st.text() | st.none())
def test_parse_returns_dict_of_strings_with_non_empty_keys(s):
    result = parse_order_modifiers(s)
    assert isinstance(result, dict)
    assert all(isinstance(k, str) and k and isinstance(v, str)
               for k, v in result.items())


# --------------------------------------------------------------------------
# 4. A few plain regression tests for the bugs fuzzing exposed
# --------------------------------------------------------------------------
def test_mocha_is_on_the_menu():
    assert lookup_drink_code("MOC") == 5.00
    assert lookup_drink_code("moca") == 5.00


def test_unknown_and_empty_codes_return_none():
    assert lookup_drink_code("XYZ") is None
    assert lookup_drink_code("") is None
    assert lookup_drink_code(None) is None


def test_average_basic_and_invalid_cases():
    assert calculate_average_shot_cost("1.0, 1.5, 2.0") == 1.5
    assert calculate_average_shot_cost("") is None
    assert calculate_average_shot_cost("1,,3") is None
    assert calculate_average_shot_cost("one,two") is None
    assert calculate_average_shot_cost("nan") is None
    assert calculate_average_shot_cost(None) is None


def test_parse_basic_and_malformed_cases():
    assert parse_order_modifiers("milk:oat;syrup:vanilla") == {
        "milk": "oat", "syrup": "vanilla"}
    assert parse_order_modifiers("") == {}
    assert parse_order_modifiers("milk") == {}
    assert parse_order_modifiers("a:b:c") == {"a": "b:c"}
    assert parse_order_modifiers(None) == {}
