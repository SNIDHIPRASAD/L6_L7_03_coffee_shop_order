"""Lab 6 - Step 1: tests written to reach >= 90% LINE coverage."""
import pytest
from coffee_shop_order import process_order_batch, check_espresso_machine


def make_order(**overrides):
    """Build a paid medium order; keyword arguments override any field."""
    order = {
        "paid": True,
        "size": "medium",
        "strict_allergy": False,
        "is_member": False,
        "customizations": [],
    }
    order.update(overrides)
    return order


# ---------------------------------------------------------------- example
def test_single_medium_coffee():
    orders = [make_order(customizations=[{"type": "standard", "cost": 0.5}])]
    result = process_order_batch(orders, 0.1)
    assert result["total"] == 5.5
    assert result["status"] == "COMPLETED"


# ------------------------------------------------------ input validation
def test_orders_not_a_list_raises():
    with pytest.raises(ValueError):
        process_order_batch("not a list", 0.1)


def test_negative_tax_rate_raises():
    with pytest.raises(ValueError):
        process_order_batch([make_order()], -0.01)


# ------------------------------------------------------------ order sizes
def test_small_size_price():
    result = process_order_batch([make_order(size="small")], 0.0)
    assert result == {"total": 3.0, "status": "COMPLETED"}


def test_large_size_price():
    result = process_order_batch([make_order(size="large")], 0.0)
    assert result == {"total": 6.0, "status": "COMPLETED"}


def test_missing_size_defaults_to_medium():
    order = make_order()
    del order["size"]
    result = process_order_batch([order], 0.0)
    assert result["total"] == 4.5


def test_unknown_size_is_rejected_and_nothing_sold():
    result = process_order_batch([make_order(size="huge")], 0.0)
    assert result == {"total": 0.0, "status": "NO_SALE"}


def test_unpaid_order_is_skipped():
    result = process_order_batch([make_order(paid=False)], 0.1)
    assert result == {"total": 0.0, "status": "NO_SALE"}


def test_empty_batch_is_no_sale():
    assert process_order_batch([], 0.1) == {"total": 0.0, "status": "NO_SALE"}


# -------------------------------------------------------- customizations
def test_syrup_added_to_price():
    order = make_order(customizations=[{"type": "syrup", "cost": 1.0}])
    result = process_order_batch([order], 0.0)
    assert result["total"] == pytest.approx(5.5)


def test_other_customization_added_to_price():
    order = make_order(customizations=[{"type": "extra_shot", "cost": 2.0}])
    result = process_order_batch([order], 0.0)
    assert result["total"] == pytest.approx(6.5)


def test_negative_cost_customization_is_ignored():
    order = make_order(customizations=[{"type": "syrup", "cost": -1.0}])
    result = process_order_batch([order], 0.0)
    assert result["total"] == pytest.approx(4.5)


def test_strict_allergy_voids_the_item():
    order = make_order(strict_allergy=True,
                       customizations=[{"type": "allergen_alert",
                                        "cost": 0.0}])
    result = process_order_batch([order], 0.1)
    assert result == {"total": 0.0, "status": "NO_SALE"}


# -------------------------------------------------------------- discounts
def test_member_gets_ten_percent_discount():
    result = process_order_batch([make_order(is_member=True)], 0.0)
    assert result["total"] == pytest.approx(4.05)


def test_multiple_paid_orders_are_summed_with_tax():
    orders = [make_order(size="small"), make_order(size="large")]
    result = process_order_batch(orders, 0.1)
    assert result == {"total": 9.9, "status": "COMPLETED"}


# ------------------------------------------------------------ audit rule
def test_more_than_four_rejections_triggers_audit():
    orders = [make_order(size="bad") for _ in range(5)]
    result = process_order_batch(orders, 0.1)
    assert result["status"] == "AUDIT_REJECTED"


# -------------------------------------------------- espresso machine
def test_machine_no_data():
    assert check_espresso_machine([]) == "NO_DATA"


def test_machine_shutdown_on_two_consecutive_overheats():
    assert check_espresso_machine([[90.0, 97.0, 98.0]]) == "SHUTDOWN"


def test_machine_optimal_when_temperatures_are_normal():
    assert check_espresso_machine([[90.0, 92.0], [93.0]]) == "OPTIMAL"
